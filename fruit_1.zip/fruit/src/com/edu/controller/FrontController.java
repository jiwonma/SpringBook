package com.edu.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FrontController extends HttpServlet {
	HashMap<String, Controller> list = null;

	@Override
	public void init(ServletConfig config) throws ServletException {
		list = new HashMap<String, Controller>(); // Controller��ü�� �������̽���.
		list.put("/sellerLogin.do", new FruitSellerLoginController());
		list.put("/buyerLogin.do", new FruitBuyerLoginController());
		list.put("/sellerJoin.do", new FruitSellerJoinController());
		list.put("/buyerJoin.do", new FruitBuyerJoinController());
		list.put("/sellerRegister.do", new FruitSellerRegisterController());
		list.put("/buyerRegister.do", new FruitBuyerRegisterController());
		list.put("/sellerInformation.do", new FruitSellerInformationController());
		list.put("/buyerInformation.do", new FruitBuyerInformationController());
		list.put("/buyerBuyFruit.do", new FruitBuyerBuyFruitController());
		list.put("/logout.do", new FruitLogoutController());
	}

	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = request.getRequestURI();
		String contextPath = request.getContextPath();
		String path = url.substring(contextPath.length());
		Controller subController = list.get(path);
		subController.execute(request, response);
	}

}