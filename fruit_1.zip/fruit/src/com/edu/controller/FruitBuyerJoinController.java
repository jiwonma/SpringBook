package com.edu.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.edu.service.FruitService;
import com.edu.vo.FruitBuyer;
import com.edu.vo.FruitSeller;

public class FruitBuyerJoinController implements Controller {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		if (id.isEmpty() || password.isEmpty()) {
			request.setAttribute("error", "��� �׸��� �Է����ֽñ� �ٶ��ϴ�.<br>");
			HttpUtil.forward(request, response, "/buyer/fruitBuyerJoin.jsp");
			return;
		}
		
		FruitService service = FruitService.getInstanse();
		String dbPassword = service.fruitBuyerLogin(id);
		if (dbPassword != null) {
				request.setAttribute("error", "�̹� �����ϴ� ���̵��Դϴ�.");
				HttpUtil.forward(request, response, "/buyer/fruitBuyerJoin.jsp");
				return;
			} else {
				FruitBuyer b = new FruitBuyer(id, password);
				service.fruitBuyerJoin(b);
				request.setAttribute("error", id+" �� ȸ�������� �Ϸ�Ǿ����ϴ�.");
				HttpUtil.forward(request, response, "/buyer/fruitBuyer.jsp");
			}
		}
		
	}