package com.edu.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.edu.service.FruitService;
import com.edu.vo.FruitBuyer;
import com.edu.vo.FruitSeller;

public class FruitBuyerBuyFruitController  implements Controller{
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		FruitService service = FruitService.getInstanse();
		
		String sellerId = request.getParameter("sellerId");
		String count = request.getParameter("count");
		
		if (sellerId.isEmpty() || count.isEmpty()) {
			request.setAttribute("error", "��� �׸��� �Է����ֽñ� �ٶ��ϴ�.");
			HttpUtil.forward(request, response, "buyer/fruitBuyerBuyFruit.jsp");
		}

		System.out.println(service.fruitSellerLogin(sellerId));
		if(service.fruitSellerLogin(sellerId)==null) {
			request.setAttribute("error", "��Ȯ�� �Ǹ��� ������ �Է����ֽñ� �ٶ��ϴ�.");
			HttpUtil.forward(request, response, "buyer/fruitBuyerBuyFruit.jsp");
		}
		FruitSeller s = service.fruitSellerInformation(sellerId);
		s.setId(sellerId);
		
		if(!(s.getAppleCount()>=Integer.parseInt(count))) {
			request.setAttribute("error", "�Ǹ� ������ �ٽ� Ȯ�����ֽñ� �ٶ��ϴ�.");
			HttpUtil.forward(request, response, "buyer/fruitBuyerBuyFruit.jsp");
			return;
		}
		HttpSession session = request.getSession(false);
		String buyerId = (String) session.getAttribute("buyerId");
		
		FruitBuyer b = service.fruitBuyerInformation(buyerId);
		b.setId(buyerId);
		
		int money = Integer.parseInt(count) * s.getApplePrice();
		b.buyFruit(s, money);
		service.buyerBuyFruit(b); service.sellerSalesFruit(s);
		HttpUtil.forward(request, response, "buyer/fruitBuyerBuyFruitOutput.jsp");
	}
}
