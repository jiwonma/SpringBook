package com.edu.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.edu.service.FruitService;

public class FruitBuyerLoginController implements Controller {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String id = request.getParameter("id");
		String password = request.getParameter("password");

		FruitService service = FruitService.getInstanse();
		String dbPassword = service.fruitBuyerLogin(id);
		if (id.isEmpty() || password.isEmpty()) {
			request.setAttribute("error", "��� �׸��� �Է����ֽñ� �ٶ��ϴ�.");
			HttpUtil.forward(request, response, "/buyer/fruitBuyer.jsp");
			return;
		}
		if (dbPassword == null) {
			request.setAttribute("error", "�������� �ʴ� ���̵��Դϴ�.");
			HttpUtil.forward(request, response, "/buyer/fruitBuyer.jsp");
			return;
		} else {
			if (!dbPassword.equals(password)) {
				request.setAttribute("error", "��й�ȣ�� �ٸ��ϴ�.");
			} else if(dbPassword.equals(password)){
				HttpSession session = request.getSession();
				session.setAttribute("buyerId", id);
				HttpUtil.forward(request, response, "/buyer/fruitBuyerMenu.jsp");
				return;
			}

			HttpUtil.forward(request, response, "/buyer/fruitBuyer.jsp");
		}

	}
}