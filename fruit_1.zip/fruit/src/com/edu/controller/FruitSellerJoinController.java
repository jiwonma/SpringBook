package com.edu.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.edu.service.FruitService;
import com.edu.vo.FruitSeller;

public class FruitSellerJoinController implements Controller {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		if (id.isEmpty() || password.isEmpty()) {
			request.setAttribute("error", "��� �׸��� �Է����ֽñ� �ٶ��ϴ�.<br>");
			HttpUtil.forward(request, response, "/seller/fruitSellerJoin.jsp");
			return;
		}
		
		FruitService service = FruitService.getInstanse();
		String dbPassword = service.fruitSellerLogin(id);
			if (dbPassword != null) {
				request.setAttribute("error", "�̹� �����ϴ� ���̵��Դϴ�.");
				HttpUtil.forward(request, response, "/seller/fruitSellerJoin.jsp");
				return;
			} else {
				FruitSeller s = new FruitSeller(id, password);
				service.fruitSellerJoin(s);
				request.setAttribute("error", id+" �� ȸ�������� �Ϸ�Ǿ����ϴ�.");
				HttpUtil.forward(request, response, "/seller/fruitSeller.jsp");
			}
		}
		
	}

