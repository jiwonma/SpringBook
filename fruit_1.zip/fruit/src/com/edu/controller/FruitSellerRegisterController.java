package com.edu.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.edu.service.FruitService;
import com.edu.vo.FruitSeller;

public class FruitSellerRegisterController implements Controller {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String count = request.getParameter("count");
		String price = request.getParameter("price");

		if (count.isEmpty() || price.isEmpty()) {
			request.setAttribute("error", "��� �׸��� �Է����ֽñ� �ٶ��ϴ�.<br>");
			HttpUtil.forward(request, response, "/seller/fruitSellerRegister.jsp");
			return;
		}
		
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("sellerId");
		FruitService service = FruitService.getInstanse();
		service.fruitSellerRegister(count,price,id);
		
		HttpUtil.forward(request, response, "/seller/fruitSellerRegisterOutput.jsp");
		}
}
