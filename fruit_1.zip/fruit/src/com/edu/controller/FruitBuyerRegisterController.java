package com.edu.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.edu.service.FruitService;
import com.edu.vo.FruitBuyer;
public class FruitBuyerRegisterController implements Controller {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		String money = request.getParameter("money");

		if (money.isEmpty()) {
			request.setAttribute("error", "�ݾ��� ��Ȯ�� �Է����ֽñ� �ٶ��ϴ�.");
			HttpUtil.forward(request, response, "/buyer/fruitBuyerRegisterMoney.jsp");
			return;
		}
		
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("buyerId");
		FruitService service = FruitService.getInstanse();
		String password = service.fruitBuyerLogin(id);
		
		FruitBuyer b = new FruitBuyer(id, password);
		b.setMoney(Integer.parseInt(money));
		
		service.fruitBuyerRegister(b);
		HttpUtil.forward(request, response, "/buyer/fruitBuyerRegisterMoneyOutput.jsp");
		}
}

