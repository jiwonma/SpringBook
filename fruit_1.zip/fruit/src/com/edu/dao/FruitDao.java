package com.edu.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.edu.vo.FruitBuyer;
import com.edu.vo.FruitSeller;

public class FruitDao {
	private static FruitDao dao = new FruitDao();

	private FruitDao() {
	}

	public static FruitDao getInstance() {
		return dao;
	}

	public Connection connect() {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test";
			String user = "root";
			String password = "cs1234";
			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			System.out.println("connect" + e);
		}
		return conn;
	}

	public void close(Connection conn, PreparedStatement ps) {
		if (ps != null) {
			try {
				ps.close();
			} catch (Exception e) {
				System.out.println("Error:close1" + e);
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
				System.out.println("Error:close2" + e);
			}
		}
	}

	public String fruitSellerLogin(String id) {
		String password = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = connect();
			pstmt = conn.prepareStatement("select password from fruitSeller where id=?");
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				password = rs.getString(1);
			}
		} catch (Exception e) {
			System.out.println("dao.fruitSellerLogin" + e);
		} finally {
			close(conn, pstmt);
		}
		return password;
	}

	public String fruitBuyerLogin(String id) {
		String password = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = connect();
			pstmt = conn.prepareStatement("select password from fruitBuyer where id=?");
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				password = rs.getString(1);
			}
		} catch (Exception e) {
			System.out.println("dao.fruitBuyerLogin" + e);
		} finally {
			close(conn, pstmt);
		}
		return password;
	}

	public void fruitSellerJoin(FruitSeller s) {
		try {
			Connection conn = connect();
			PreparedStatement pstmt = conn.prepareStatement("insert into fruitseller values(?,?,?,?,?)");
			pstmt.setString(1, s.getId());
			pstmt.setString(2, s.getPassword());
			pstmt.setString(3, s.getMoney() + "");
			pstmt.setString(4, s.getAppleCount() + "");
			pstmt.setString(5, s.getApplePrice() + "");
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("dao.fruitSellerJoin" + e);
		}
	}

	public void fruitBuyerJoin(FruitBuyer b) {
		try {
			Connection conn = connect();
			PreparedStatement pstmt = conn.prepareStatement("insert into fruitbuyer values(?,?,?,?)");
			pstmt.setString(1, b.getId());
			pstmt.setString(2, b.getPassword());
			pstmt.setString(3, b.getMoney() + "");
			pstmt.setString(4, b.getAppleCount() + "");
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("dao.fruitBuyerJoin" + e);
		}
	}

	public void fruitSellerRegister(String count, String price, String id) {
		try {
			Connection conn = connect();
			PreparedStatement pstmt = conn.prepareStatement("update fruitseller set count=?, price=? where id=?");
			pstmt.setString(1, count);
			pstmt.setString(2, price);
			pstmt.setString(3, id);
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("dao.fruitSellerRegister" + e);
		}
	}

	public void fruitBuyerRegister(FruitBuyer b) {
		try {
			Connection conn = connect();
			PreparedStatement pstmt = conn.prepareStatement("update fruitbuyer set money=? where id=?");
			pstmt.setString(1, b.getMoney() + "");
			pstmt.setString(2, b.getId());
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("dao.fruitBuyerRegister" + e);
		}
	}

	public FruitSeller fruitSellerInformation(String id) {
		FruitSeller s = new FruitSeller();
		try {
			Connection conn = connect();
			PreparedStatement pstmt = conn.prepareStatement("select * from fruitseller where id=?");
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				s.setPassword(rs.getString(2));
				s.setMoney(Integer.parseInt(rs.getString(3)));
				s.setAppleCount(Integer.parseInt(rs.getString(4)));
				s.setApplePrice(Integer.parseInt(rs.getString(5)));
			}
		} catch (Exception e) {
			System.out.println("dao.fruitSellerInformation" + e);
		}
		return s;
	}
	public FruitBuyer fruitBuyerInformation(String id) {
		FruitBuyer b = new FruitBuyer();
		try {
			Connection conn = connect();
			PreparedStatement pstmt = conn.prepareStatement("select * from fruitbuyer where id=?");
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				b.setPassword(rs.getString(2));
				b.setMoney(Integer.parseInt(rs.getString(3)));
				b.setAppleCount(Integer.parseInt(rs.getString(4)));
			}
		} catch (Exception e) {
			System.out.println("dao.fruitBuyerInformation" + e);
		}
		return b;
	}
	

	public ArrayList<FruitSeller> FruitSellerList() {
		ArrayList<FruitSeller> list = new ArrayList<FruitSeller>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		FruitSeller s = null;
		try {
			conn = connect();
			pstmt = conn.prepareStatement("select * from fruitseller");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				s = new FruitSeller();
				s.setId(rs.getString(1));
				s.setPassword(rs.getString(2));
				s.setMoney(Integer.parseInt(rs.getString(3)));
				s.setAppleCount(Integer.parseInt(rs.getString(4)));
				s.setApplePrice(Integer.parseInt(rs.getString(5)));
				list.add(s);
			}
		} catch (Exception e) {
		} finally {
			close(conn, pstmt);
		}
		return list;
	}
	public void buyerBuyFruit(FruitBuyer b) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = connect();
			pstmt = conn.prepareStatement("update fruitbuyer set money=?, count=? where id=?");
			pstmt.setString(1, b.getMoney()+"");
			pstmt.setString(2, b.getAppleCount()+"");
			pstmt.setString(3, b.getId());
			pstmt.executeUpdate();
			} catch (Exception e) {
			System.out.println("dao.buyerBuyFruit" + e);
		}
	}
	public void sellerSalesFruit(FruitSeller s) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = connect();
			pstmt = conn.prepareStatement("update fruitseller set money=?, count=? where id=?");
			pstmt.setString(1, s.getMoney()+"");
			pstmt.setString(2, s.getAppleCount()+"");
			pstmt.setString(3, s.getId());
			pstmt.executeUpdate();
			} catch (Exception e) {
			System.out.println("dao.sellerSalesFruit" + e);
		}
	}

}
