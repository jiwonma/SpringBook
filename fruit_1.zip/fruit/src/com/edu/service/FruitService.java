package com.edu.service;

import java.util.ArrayList;

import com.edu.dao.FruitDao;
import com.edu.vo.FruitBuyer;
import com.edu.vo.FruitSeller;

public class FruitService {
	private static FruitService service = new FruitService();
	private FruitDao dao = FruitDao.getInstance();
	private FruitService() {}
	
	public static FruitService getInstanse() {
		return service;
	}
	
	public String fruitSellerLogin(String id) {
		return dao.fruitSellerLogin(id);
	}
	public String fruitBuyerLogin(String id) {
		return dao.fruitBuyerLogin(id);
	}
	public void fruitSellerJoin(FruitSeller s) {
		dao.fruitSellerJoin(s);
	}
	public void fruitBuyerJoin(FruitBuyer b) {
		dao.fruitBuyerJoin(b);
	}
	public void fruitSellerRegister(String count, String price, String id) {
		dao.fruitSellerRegister(count,price,id);
	}
	public void fruitBuyerRegister(FruitBuyer b) {
		dao.fruitBuyerRegister(b);
	}
	public FruitSeller fruitSellerInformation(String id) {
		return dao.fruitSellerInformation(id);
	}
	public FruitBuyer fruitBuyerInformation(String id) {
		return dao.fruitBuyerInformation(id);
	}
	public ArrayList<FruitSeller> FruitSellerList() {
		return dao.FruitSellerList();
	}
	public void buyerBuyFruit(FruitBuyer b) {
		dao.buyerBuyFruit(b);
	}
	public void sellerSalesFruit(FruitSeller s) {
		dao.sellerSalesFruit(s);
	}
	
}
